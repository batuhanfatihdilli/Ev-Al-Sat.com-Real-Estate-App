package com.example.ev_ilani

import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.UUID

class AddHouseActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var etTitle: EditText
    private lateinit var etArea: EditText
    private lateinit var etRoomCount: EditText
    private lateinit var etPrice: EditText
    private lateinit var etCity: EditText
    private lateinit var btnPublish: Button
    private val PICK_IMAGE_REQUEST = 1
    private var imageUri: Uri? = null
    private lateinit var storageReference: StorageReference
    private lateinit var firestore: FirebaseFirestore

    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_house)

        imageView = findViewById(R.id.imageView)
        etTitle = findViewById(R.id.etTitle)
        etArea = findViewById(R.id.etArea)
        etRoomCount = findViewById(R.id.etRoomCount)
        etPrice = findViewById(R.id.etPrice)
        etCity = findViewById(R.id.etCity)
        btnPublish = findViewById(R.id.btnPublish)

        storageReference = FirebaseStorage.getInstance().reference
        firestore = FirebaseFirestore.getInstance()

        imageView.setOnClickListener {
            // Fotoğraf yüklemek için izin kontrolü yap
            openGallery()
        }

        btnPublish.setOnClickListener {
            publishHouse()
        }
    }

    // Galeriyi açma fonksiyonu
    private fun openGallery() {
        val permissionStatus = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_IMAGES)
        if (permissionStatus == PackageManager.PERMISSION_GRANTED) {
            Log.d("Permission", "İzin zaten verilmiş")
            Toast.makeText(this, "İzin zaten verilmiş", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        } else {
            // İzin verilmediyse izin iste
            Log.d("Permission", "İzin isteniyor")
            Toast.makeText(this, "Fotoğraf erişimi için izin isteniyor", Toast.LENGTH_SHORT).show()
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES),
                PERMISSION_REQUEST_CODE)
        }
    }

    // Fotoğraf seçildikten sonra işlem yapma
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageUri = data.data
            imageView.setImageURI(imageUri)
        }
    }

    // Ev bilgilerini yayımlama fonksiyonu
    private fun publishHouse() {
        val title = etTitle.text.toString()
        val area = etArea.text.toString()
        val roomCount = etRoomCount.text.toString()
        val price = etPrice.text.toString()
        val city = etCity.text.toString()

        if (imageUri != null && title.isNotEmpty() && area.isNotEmpty() && roomCount.isNotEmpty() && price.isNotEmpty() && city.isNotEmpty()) {
            val fileReference = storageReference.child("house_images/${UUID.randomUUID()}.jpg")
            fileReference.putFile(imageUri!!).addOnSuccessListener {
                fileReference.downloadUrl.addOnSuccessListener { uri ->
                    val house = hashMapOf(
                        "title" to title,
                        "area" to area,
                        "roomCount" to roomCount,
                        "price" to price,
                        "city" to city,
                        "imageUrl" to uri.toString(),
                        "userEmail" to FirebaseAuth.getInstance().currentUser?.email,
                        "timestamp" to System.currentTimeMillis() // timestamp ekleniyor
                    )

                    firestore.collection("houses").add(house).addOnSuccessListener {
                        Toast.makeText(this, "Ev başarıyla eklendi", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }.addOnFailureListener {
                        Toast.makeText(this, "Ev eklenirken hata oluştu", Toast.LENGTH_SHORT).show()
                    }
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Resim yüklenirken hata oluştu", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show()
        }
    }

    // Kullanıcının verdiği izin sonucunu kontrol et
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission", "İzin verildi")
                Toast.makeText(this, "İzin verildi", Toast.LENGTH_SHORT).show()
                // İzin verildikten sonra galeriyi aç
                openGallery()
            } else {
                Log.d("Permission", "İzin reddedildi")
                Toast.makeText(this, "İzin verilmedi. Lütfen fotoğraf erişimine izin verin.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
