package com.example.ev_ilani

data class House(
    val title: String = "",
    val area: String = "",
    val roomCount: String = "",
    val price: String = "",
    val city: String = "",
    val imageUrl: String = "",
    val userEmail: String = "",
    val timestamp: Long = System.currentTimeMillis()  // Yeni alan
)
 {
    // Parametresiz yapıcı, Firestore'un veri çekebilmesi için gerekli
    constructor() : this("", "", "", "", "", "", "")
}

