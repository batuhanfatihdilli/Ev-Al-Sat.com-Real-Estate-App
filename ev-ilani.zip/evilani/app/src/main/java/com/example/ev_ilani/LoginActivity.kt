package com.example.ev_ilani

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {

    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var btnLogin: Button

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // UI bileşenlerini bağlama
        edtEmail = findViewById(R.id.edtEmail)
        edtPassword = findViewById(R.id.edtPassword)
        btnRegister = findViewById(R.id.btnRegister)
        btnLogin = findViewById(R.id.btnLogin)

        // Kayıt ol butonuna tıklama işlemi
        btnRegister.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()

            // Gerekli kontrolleri yapalım
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!email.endsWith("@gmail.com")) {
                Toast.makeText(this, "Geçersiz e-posta. Lütfen @gmail.com ile biten bir e-posta girin.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Firestore'da bu e-posta var mı diye kontrol etme
            db.collection("users").whereEqualTo("email", email).get()
                .addOnSuccessListener { documents ->
                    if (!documents.isEmpty) {
                        Toast.makeText(this, "Bu e-posta ile zaten kayıtlı bir kullanıcı var.", Toast.LENGTH_SHORT).show()
                    } else {
                        // Eğer yoksa yeni kullanıcı kaydedelim
                        auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    // Kullanıcı oluşturuldu
                                    val user = hashMapOf("email" to email)
                                    val userId = auth.currentUser?.uid

                                    // Kullanıcı Firestore'a kaydedilecek
                                    if (userId != null) {
                                        db.collection("users").document(userId).set(user)
                                            .addOnSuccessListener {
                                                Log.d("LoginActivity", "Kullanıcı Firestore'a kaydedildi")
                                                Toast.makeText(this, "Kayıt başarılı!", Toast.LENGTH_SHORT).show()
                                                navigateToMainActivity() // Başarılıysa yönlendirme
                                            }
                                            .addOnFailureListener { e ->
                                                Log.e("LoginActivity", "Firestore kaydı başarısız: ", e)
                                                Toast.makeText(this, "Kayıt işlemi başarısız!", Toast.LENGTH_SHORT).show()
                                            }

                                        // Burada Firestore kaydı başarılı mı kontrol edelim
                                        Log.d("LoginActivity", "Firestore kaydı başarıyla yapıldı")
                                    }
                                } else {
                                    Log.e("LoginActivity", "Kullanıcı oluşturulamadı: ${task.exception?.message}")
                                    Toast.makeText(this, "Kayıt işlemi başarısız!", Toast.LENGTH_SHORT).show()
                                }

                                // Burada kayıt işleminin sonucunu logluyoruz
                                if (task.isSuccessful) {
                                    Log.d("LoginActivity", "Kullanıcı başarıyla oluşturuldu")
                                } else {
                                    Log.d("LoginActivity", "Kullanıcı oluşturulamadı: ${task.exception?.message}")
                                }
                            }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("LoginActivity", "Firestore sorgusu başarısız: ", e)
                    Toast.makeText(this, "Hata oluştu!", Toast.LENGTH_SHORT).show()
                }
        }

        // Giriş yap butonuna tıklama işlemi
        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()

            // Giriş için kontroller
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Firebase Authentication ile giriş işlemi
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d("LoginActivity", "Giriş başarılı")
                        Toast.makeText(this, "Giriş başarılı!", Toast.LENGTH_SHORT).show()
                        // Ana sayfaya yönlendirme
                        navigateToMainActivity()
                    } else {
                        Log.d("LoginActivity", "Giriş başarısız: ${task.exception?.message}")
                        Toast.makeText(this, "Giriş başarısız! E-posta veya şifreyi kontrol edin.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    // MainActivity'ye yönlendirme işlevi
    private fun navigateToMainActivity() {
        Log.d("LoginActivity", "Yönlendirme MainActivity'ye yapılacak")
        startActivity(Intent(this, MainActivity::class.java))
        finish() // LoginActivity'yi sonlandır
    }
}
