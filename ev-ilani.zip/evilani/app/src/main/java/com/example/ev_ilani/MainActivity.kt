package com.example.ev_ilani

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.FrameLayout
import android.widget.ImageView
import android.view.animation.TranslateAnimation
import android.view.animation.Animation
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.widget.Toast
import android.view.Menu
import android.view.MenuItem

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: HouseAdapter
    private lateinit var houseList: MutableList<House>
    private lateinit var firestore: FirebaseFirestore
    private lateinit var frameLayout: FrameLayout
    private val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Firebase oturum kontrolü
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            // Eğer kullanıcı giriş yapmamışsa, login ekranına yönlendir
            startActivity(Intent(this, LoginActivity::class.java))
            finish() // MainActivity'yi kapatıyoruz ki geri tuşu ile tekrar açılmasın
            return
        }

        // Eğer kullanıcı giriş yapmışsa, ana sayfa açılır
        setContentView(R.layout.activity_main)

        frameLayout = findViewById(R.id.frameLayout)

        // Kar tanesi animasyonunu başlat
        startSnowfall()

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Ev Al-Sat.com"
        toolbar.setBackgroundColor(resources.getColor(R.color.colorPrimary))

        // RecyclerView için hazırlık
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        houseList = mutableListOf()
        adapter = HouseAdapter(houseList)
        recyclerView.adapter = adapter

        firestore = FirebaseFirestore.getInstance()

        // Firestore'dan verileri alıyoruz ve timestamp'e göre sıralıyoruz
        firestore.collection("houses")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING) // timestamp'e göre azalan sırada
            .get()
            .addOnSuccessListener { result ->
                houseList.clear()
                for (document in result) {
                    val house = document.toObject(House::class.java)
                    houseList.add(house)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this@MainActivity, "Veriler alınırken hata oluştu: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Menü oluşturma
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu) // Menü XML'ini yükle
        return true
    }

    // Menü öğesine tıklama işlemi
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                FirebaseAuth.getInstance().signOut() // Kullanıcıyı çıkış yapma
                startActivity(Intent(this, LoginActivity::class.java)) // Giriş ekranına yönlendir
                finish() // MainActivity'yi kapatıyoruz
                true
            }
            R.id.menu_add_house -> {
                // Ev ekleme sayfasına yönlendir
                startActivity(Intent(this, AddHouseActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun startSnowfall() {
        val runnable = object : Runnable {
            override fun run() {
                // Kar tanesi ekleme
                val snowflake = ImageView(this@MainActivity)
                snowflake.setImageResource(R.drawable.snowflake) // Kar taneleri görselini kullan

                // Kar tanesini ekleme
                val layoutParams = FrameLayout.LayoutParams(75, 75) // Kar tanelerinin boyutunu küçültüyoruz
                layoutParams.leftMargin = (Math.random() * frameLayout.width).toInt() // Ekranın genişliğine göre rastgele pozisyon
                layoutParams.topMargin = -100 // Başlangıç noktası, ekranın üstü
                frameLayout.addView(snowflake, layoutParams)

                // Animasyon ile aşağıya hareket etmesini sağlama
                val animation = TranslateAnimation(0f, 0f, 0f, frameLayout.height.toFloat()) // Y ekseninde tam ekran boyu hareket
                animation.duration = (Math.random() * 15000 + 10000).toLong() // Kar tanelerinin daha yavaş hareket etmesi için animasyon süresi
                animation.repeatCount = Animation.INFINITE // Sonsuza kadar devam et
                snowflake.startAnimation(animation)

                handler.postDelayed(this, 2000)
            }
        }

        // Animasyonu başlat
        handler.post(runnable)
    }
}
