package com.example.ev_ilani

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class HouseAdapter(private val houseList: List<House>) : RecyclerView.Adapter<HouseAdapter.HouseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HouseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_house, parent, false)
        return HouseViewHolder(view)
    }

    override fun onBindViewHolder(holder: HouseViewHolder, position: Int) {
        val house = houseList[position]
        holder.bind(house)
    }

    override fun getItemCount(): Int = houseList.size

    inner class HouseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.tvTitle)
        private val area: TextView = itemView.findViewById(R.id.tvArea)
        private val roomCount: TextView = itemView.findViewById(R.id.tvRoomCount)
        private val price: TextView = itemView.findViewById(R.id.tvPrice)
        private val city: TextView = itemView.findViewById(R.id.tvCity)
        private val imageView: ImageView = itemView.findViewById(R.id.ivHouseImage)
        private val userEmail: TextView = itemView.findViewById(R.id.tvUserEmail)

        fun bind(house: House) {
            title.text = house.title
            area.text = "Alan: ${house.area} m²"
            roomCount.text = "Oda Sayısı: ${house.roomCount}"
            price.text = "Fiyat: ${house.price} ₺"
            city.text = "Şehir: ${house.city}"
            userEmail.text = "Kullanıcı: ${house.userEmail}"

            // Picasso ile resim yükleme
            Picasso.get()
                .load(house.imageUrl)
                .into(imageView)
        }
    }
}
